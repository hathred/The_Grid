# DML Archive: dml_archive_20251102_164905

**Generated:** 2025-11-02T16:49:05.192473  
**DML Count:** 41  
**Total Size:** 51,226 bytes  

## Files
- `DIRECTORY_MANIFEST.md.dml.b64` (648 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `000_Project_Manifests\DIRECTORY_MANIFEST.md.dml.b64` (1,944 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `000_Project_Manifests\manifest.yml.dml.b64` (3,338 bytes) ← `manifest.yml.dml`
- `000_Project_Manifests\SETUP_WINDOWS.md.dml.b64` (707 bytes) ← `SETUP_WINDOWS.md.dml`
- `010_Data_RDBMS_NoSQL\DIRECTORY_MANIFEST.md.dml.b64` (1,692 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `020_SCM_Version_Control\DIRECTORY_MANIFEST.md.dml.b64` (1,608 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `020_SCM_Version_Control\Gitlab_install_instructions.txt.dml.b64` (354 bytes) ← `Gitlab_install_instructions.txt.dml`
- `030_Auth_Identity_Management\DIRECTORY_MANIFEST.md.dml.b64` (1,564 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `040_Web_Server_Frontend\DIRECTORY_MANIFEST.md.dml.b64` (1,612 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `050_Network_Core_Services\DIRECTORY_MANIFEST.md.dml.b64` (664 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `060_Virtualization_Containerization\Airflow_install_instructions.txt.dml.b64` (399 bytes) ← `Airflow_install_instructions.txt.dml`
- `060_Virtualization_Containerization\DIRECTORY_MANIFEST.md.dml.b64` (668 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `060_Virtualization_Containerization\Prefect_install_instructions.txt.dml.b64` (363 bytes) ← `Prefect_install_instructions.txt.dml`
- `070_DevOps_CI_CD\DIRECTORY_MANIFEST.md.dml.b64` (656 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `080_Observability_ELK_Stack\DIRECTORY_MANIFEST.md.dml.b64` (668 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `090_Messaging_IoT_Broker\DIRECTORY_MANIFEST.md.dml.b64` (664 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `105_System_Automation_Scripts\DIRECTORY_MANIFEST.md.dml.b64` (660 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `110_Cybersecurity_Pentest\DIRECTORY_MANIFEST.md.dml.b64` (660 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `120_Blockchain_Crypto\DIRECTORY_MANIFEST.md.dml.b64` (660 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `130_MUD_IRC_Community\DIRECTORY_MANIFEST.md.dml.b64` (660 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `140_Game_Development\DIRECTORY_MANIFEST.md.dml.b64` (652 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `150_Offline_Chat_Messaging\DIRECTORY_MANIFEST.md.dml.b64` (660 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `160_Mirror_Tool_Dependencies\DIRECTORY_MANIFEST.md.dml.b64` (656 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `170_OS_Security_Baselines\DIRECTORY_MANIFEST.md.dml.b64` (664 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `180_Open_Source_Intelligence\DIRECTORY_MANIFEST.md.dml.b64` (664 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `190_Local_CDN_Caching\DIRECTORY_MANIFEST.md.dml.b64` (660 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `195_Documentation_Knowledge_Base\DIRECTORY_MANIFEST.md.dml.b64` (672 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `200_Content_Data_Source\DIRECTORY_MANIFEST.md.dml.b64` (644 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `210_Project_Dev_Tools\DIRECTORY_MANIFEST.md.dml.b64` (648 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `990_Project_Automation\auto_download_manifest.json.dml.b64` (450 bytes) ← `auto_download_manifest.json.dml`
- `990_Project_Automation\DIRECTORY_MANIFEST.md.dml.b64` (636 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `990_Project_Automation\TEMPLATE_DIRECTORY_MANIFEST.md.dml.b64` (1,233 bytes) ← `TEMPLATE_DIRECTORY_MANIFEST.md.dml`
- `995_Project_Logs\DIRECTORY_MANIFEST.md.dml.b64` (640 bytes) ← `DIRECTORY_MANIFEST.md.dml`
- `995_Project_Logs\filelist_post_mirroring.txt.dml.b64` (9,074 bytes) ← `filelist_post_mirroring.txt.dml`
- `990_Project_Automation\Pipeline\config.yaml.dml.b64` (666 bytes) ← `config.yaml.dml`
- `990_Project_Automation\Pipeline\grok_config_yaml.txt.dml.b64` (2,467 bytes) ← `grok_config_yaml.txt.dml`
- `990_Project_Automation\Pipeline\project_summary.md.dml.b64` (7,969 bytes) ← `project_summary.md.dml`
- `990_Project_Automation\Pipeline\requirements.txt.dml.b64` (359 bytes) ← `requirements.txt.dml`
- `210_Project_Dev_Tools\Summarize\DML_SUMMARY.md.dml.b64` (613 bytes) ← `DML_SUMMARY.md.dml`
- `180_Open_Source_Intelligence\Datasets\OhShINT.txt.dml.b64` (378 bytes) ← `OhShINT.txt.dml`
- `160_Mirror_Tool_Dependencies\NODE\node__docker_instructions.txt.dml.b64` (632 bytes) ← `node__docker_instructions.txt.dml`
